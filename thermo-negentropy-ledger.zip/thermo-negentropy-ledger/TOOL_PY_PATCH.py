"""tool.py — Surgical Patch Instructions (v1.5.0)

Apply these exact edits to tool.py. Each patch is a find/replace pair.
Line numbers are approximate (from tool2.pdf rendering).

===========================================================================
PATCH 1: Remove radiation_spectral from CANONICAL_ALPHA  (page 2, ~line 55)
===========================================================================

FIND:
------
CANONICAL_ALPHA: Dict[str, float] = {
    "work":               0.0,
    "chemical":           0.0,
    "heat":               1.0,
    "radiation_bb":       4.0 / 3.0,
    "radiation_spectral": 4.0 / 3.0,
}

REPLACE WITH:
------
# Canonical alphas — structural thermodynamic constants.
# radiation_spectral is NOT here: its alpha genuinely varies in [0, 4/3].
# See carrier_constants.py for the authoritative alpha enforcement logic.
CANONICAL_ALPHA: Dict[str, float] = {
    "work":         0.0,
    "chemical":     0.0,
    "heat":         1.0,
    "radiation_bb": 4.0 / 3.0,
}

WHY:
    radiation_spectral is the ONLY carrier whose alpha is a measured/modeled
    quantity, not a structural constant.  By including it at 4/3, leg_alpha()
    silently overrides any declared alpha_eff (e.g., 0.01 for a laser-like
    low-entropy beam) with 4/3.  This corrupts every spectral radiation leg's
    Ndot and exergy with zero warning.

    carrier_constants.py already handles this correctly: it excludes
    radiation_spectral from CANONICAL_ALPHA and enforces Petela bounds
    [0, 4/3] via enforce_canonical_alpha().


===========================================================================
PATCH 2: Update leg_alpha() to handle radiation_spectral  (page 5-6)
===========================================================================

FIND (in leg_alpha function, after computing `canonical`):
------
    stored = leg.get("alpha")
    if stored is None:
        stored = leg.get("alpha_eff")
    if stored is not None:
        stored_f = float(stored)
        if abs(stored_f - canonical) > 1e-9:
            msg = (
                f"leg '{leg.get('leg_id', '?')}': stored alpha={stored_f} contrad"
                f"canonical alpha={canonical:.6f} for carrier '{cc}'. "
                "Alpha is a structural constant. Remove or correct the alpha fiel"
            )
            if strict:
                raise ValueError(msg)

    return canonical

REPLACE WITH:
------
    # --- radiation_spectral: bounded, not fixed ---
    if cc == "radiation_spectral":
        stored = leg.get("alpha_eff", leg.get("alpha"))
        if stored is None:
            raise ValueError(
                f"leg '{leg.get('leg_id', '?')}': radiation_spectral requires "
                "alpha_eff (the entropy-to-energy ratio depends on spectral shape)"
            )
        val = float(stored)
        if not (0.0 <= val <= 4.0 / 3.0 + 1e-9):
            msg = (
                f"leg '{leg.get('leg_id', '?')}': alpha_eff={val:.6f} outside "
                f"Petela bounds [0, 4/3] for radiation_spectral"
            )
            if strict:
                raise ValueError(msg)
        return val

    # --- All other carriers: fixed canonical value ---
    stored = leg.get("alpha")
    if stored is None:
        stored = leg.get("alpha_eff")
    if stored is not None:
        stored_f = float(stored)
        if abs(stored_f - canonical) > 1e-9:
            msg = (
                f"leg '{leg.get('leg_id', '?')}': stored alpha={stored_f} "
                f"contradicts canonical alpha={canonical:.6f} for carrier '{cc}'. "
                "Alpha is a structural constant. Remove or correct the alpha field."
            )
            if strict:
                raise ValueError(msg)

    return canonical

WHY:
    Aligns the validator/CLI path with carrier_constants.py.  Spectral
    radiation legs now pass through their declared alpha_eff (bounds-checked)
    instead of being silently forced to 4/3.


===========================================================================
PATCH 3: Update CANONICAL_CARRIERS to include radiation_spectral  (page 2)
===========================================================================

VERIFY this already exists:
------
CANONICAL_CARRIERS: set[str] = {"work", "chemical", "heat", "radiation_bb",
                                "radiation_spectral"}

NO CHANGE NEEDED — radiation_spectral is a valid carrier, just not a
fixed-alpha one.


===========================================================================
PATCH 4: Fix T_CMB fallback value  (page 1, ImportError block)
===========================================================================

FIND:
------
    T_CMB = 2.72548

REPLACE WITH:
------
    T_CMB = 2.725

WHY:
    Consistency with mc_distributions.T_FLOOR_CMB_K = 2.725 (3 dp for
    readability, within Fixsen 2009 1σ of ±0.00057 K).


===========================================================================
PATCH 5: Fix hardcoded v1.4 in --build-dist zip name  (last page)
===========================================================================

FIND:
------
    _out = _os.path.join(_src, "..", "Thermo-negentropy-Ledger-v1.4.zip")

REPLACE WITH:
------
    _ver = "1.5.0"
    try:
        from carrier_constants import __version__ as _ver
    except ImportError:
        pass
    _out = _os.path.join(_src, "..", f"Thermo-negentropy-Ledger-v{_ver}.zip")

WHY:
    Zip artifact name must match the code version inside it.  Now driven
    from carrier_constants.__version__ with a safe fallback.


===========================================================================
PATCH 6: Fix hardcoded v1.4 in --build-zip copy path  (last page)
===========================================================================

FIND:
------
    _dest = "/mnt/user-data/outputs/Thermo-negentropy-Ledger-v1.4.zip"

REPLACE WITH:
------
    _dest = f"/mnt/user-data/outputs/Thermo-negentropy-Ledger-v{_ver}.zip"

WHY:
    Same version-drift fix for the copy-to-outputs path.
"""
