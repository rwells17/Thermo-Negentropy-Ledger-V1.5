"""uncertainty_propagation.py

Monte Carlo uncertainty propagation for the Thermodynamic Negentropy Ledger.

DESIGN PHILOSOPHY:
  - Representation (cheap):  uncertainty % stored per parameter in JSON.
  - Propagation (expensive): this module — opt-in, CLI flag --mc-samples N.

WHY MONTE CARLO INSTEAD OF CARNOT BOUNDS:
    Carnot gives a deterministic upper ceiling.  That's useful but it tells you
    nothing about how measurement uncertainty in T_source, T_sink, or P_W
    propagates into uncertainty in Ndot, W_ex, eta, or bits/s.  MC sampling
    answers: "given my +/-X% knowledge of these inputs, what is the 95% CI on
    efficiency?"  This is critical for evaluating feasibility of hypothetical
    systems: a system that looks 38% efficient may be anywhere from 32-44%
    once instrumentation uncertainty is accounted for.

USAGE:
    from uncertainty_propagation import monte_carlo_system, print_mc_report
    result = monte_carlo_system(system_dict, n_samples=10000, seed=42)
    print_mc_report(result)

    Or via CLI:
    python3 uncertainty_propagation.py data.json Sun --samples 10000

CHANGES (v1.5 BUG FIXES — see CHANGELOG.md for full detail):
    1. SINGLE-PASS RNG: monte_carlo_system no longer re-samples with a second
       RNG.  The old code created rng2=default_rng(seed) and resampled all
       parameters independently of the per-leg pass.  While the draws were
       nominally identical (same seed, same call order), ANY divergence in
       code path between the two passes (e.g., a conditional branch, a warning
       that consumed RNG state) would silently decorrelate the per-leg and
       system-level statistics.  Now monte_carlo_leg returns raw sample arrays,
       and monte_carlo_system aggregates them directly.  One pass, one truth.

    2. CONSISTENT CI WIDTH: per-leg block() previously hardcoded 2.5/97.5
       percentiles while system-level used the confidence_level
       parameter.  Now both use the same confidence_level.

    3. T0 DEFAULT: system.get("dead_state_T0_K", 298.15) silently defaulted
       to 298.15 K for astrophysical systems, inflating every exergy result.
       Now emits an explicit warning and flags the result.

    4. FALLBACK PATHS: when mc_distributions is not importable, the Gaussian
       fallback now runs constraint auditing (previously skipped entirely).
       The fallback alpha_for_mc now returns 0.0 for work-like carriers
       instead of blindly passing through the declared value.

    5. ALPHA COMPARISON: _leg_ndot_vec used alpha == 0.0 (exact float).
       Now uses abs(alpha) < 1e-12 for IEEE robustness.
"""
import math
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from scipy import stats

__version__ = "1.5.0"

# ===========================================================================
# Constants — from single source of truth (constants.py)
# ===========================================================================
try:
    from engine.constants import K_B, LN2, KBLN2, BITS_PER_J_PER_K
except ImportError:
    # Fallback: SI 2019 exact value for Boltzmann constant.
    K_B = 1.380649e-23          # J/K  (exact by definition since 2019 SI)
    LN2 = math.log(2)          # 0.6931471805599453...
    KBLN2 = K_B * LN2          # k_B * ln(2)
    BITS_PER_J_PER_K = 1.0 / KBLN2

# ===========================================================================
# Regime-aware distributions and physical constraint auditing
# ===========================================================================
try:
    from engine.mc_distributions import (
        sample_temperature, sample_power, sample_efficiency,
        check_physical_constraints, interpret_constraint_violations,
        t_floor_for_regime, select_distribution,
        INVALID_DRAW_WARN_THRESHOLD,
    )
    _MC_DIST_AVAILABLE = True
except ImportError:
    _MC_DIST_AVAILABLE = False

# Canonical alpha enforcement
try:
    from engine.carrier_constants import canonical_name as _canonical_name, alpha_for_mc
    _CARRIER_CONST_AVAILABLE = True
except ImportError:
    _CARRIER_CONST_AVAILABLE = False

    def _canonical_name(c):
        aliases = {
            "electricity": "work", "mechanical": "work",
            "electric": "work", "shaft": "work", "shaft_work": "work",
        }
        return aliases.get(c.lower(), c.lower())

    def alpha_for_mc(carrier, declared_alpha):
        """Fallback alpha_for_mc when carrier_constants is not importable.

        SAFETY: for known canonical carriers, returns the exact analytical
        value rather than blindly passing through the declared alpha.
        This prevents silent corruption if the JSON has a wrong alpha and
        carrier_constants.py is absent.
        """
        name = _canonical_name(carrier)
        _FALLBACK_CANONICAL = {"work": 0.0, "chemical": 0.0, "heat": 1.0,
                               "radiation_bb": 4.0 / 3.0}
        if name in _FALLBACK_CANONICAL:
            return _FALLBACK_CANONICAL[name]
        # radiation_spectral or unknown: pass through (no better option)
        return declared_alpha


# ===========================================================================
# Default uncertainty fallback
# ===========================================================================
# When a parameter has no declared uncertainty_pct in the JSON, we assume 5%.
# This is a conservative default: large enough to produce meaningful CIs,
# small enough to not dominate the error budget.  It is ALWAYS flagged in
# the output as "warned_fallback": true so the user knows it was imputed.
_DEFAULT_UNCERTAINTY_PCT: float = 5.0

# Numeric epsilon for alpha comparison.  Avoids exact float == 0.0 tests
# which fail under IEEE arithmetic when alpha is computed rather than stored.
_ALPHA_EPS: float = 1e-12


# ===========================================================================
# Internal sampling dispatcher
# ===========================================================================
def _sample_param(
    param_name: str,
    value: float,
    uncertainty_pct: float,
    n: int,
    rng: np.random.Generator,
    carrier: str = "",
    regime: str = "",
) -> np.ndarray:
    """Dispatch to the physically correct distribution for this parameter type.

    Replaces the old sample_parameter() which used Gaussian for everything.
    Distributions:
        P_W       -> log-normal (multiplicative calibration uncertainty)
        T_*_K     -> truncated normal (physical lower bound enforced)
        eta_use   -> Beta (bounded [0, 1] by construction)
        alpha     -> FIXED for canonical carriers (not sampled)
    """
    if not _MC_DIST_AVAILABLE:
        # Fallback: old Gaussian behaviour (flagged in warnings by caller)
        sigma = abs(value) * (uncertainty_pct / 100.0)
        if sigma == 0:
            return np.full(n, value)
        samples = rng.normal(loc=value, scale=sigma, size=n)
        # Apply physical bounds: clamp to small positive for positive-definite
        # quantities, leave unconstrained otherwise.
        if value > 0:
            return np.clip(samples, 1e-300, None)
        return np.clip(samples, None, 0.0) if value < 0 else samples

    dist = select_distribution(param_name, carrier, regime)

    if dist == "fixed":
        return np.full(n, value)
    if dist == "lognormal":
        return sample_power(value, uncertainty_pct, n, rng)
    if dist == "truncnorm":
        floor = t_floor_for_regime(regime)
        return sample_temperature(value, uncertainty_pct, n, rng, t_floor_K=floor)
    if dist == "beta":
        return sample_efficiency(value, uncertainty_pct, n, rng)
    if dist == "uniform":
        half = abs(value) * (uncertainty_pct / 100.0)
        lo = max(0.0, value - half)
        hi = min(4.0 / 3.0, value + half)
        return rng.uniform(lo, hi, size=n)
    # Fallback normal
    sigma = abs(value) * (uncertainty_pct / 100.0)
    return rng.normal(loc=value, scale=sigma, size=n)


# ===========================================================================
# Vectorised physics computations
# ===========================================================================
def _leg_ndot_vec(
    P: np.ndarray,
    T_sink: np.ndarray,
    T_source: Optional[np.ndarray],
    alpha: float,
) -> np.ndarray:
    """Vectorised Ndot = P * (1/T_sink - alpha/T_source)."""
    # Use tolerance-based comparison instead of exact float == 0.0.
    # This handles cases where alpha was computed (e.g., 0.0 + epsilon
    # from a subtraction) rather than stored as a literal.
    if abs(alpha) < _ALPHA_EPS:
        return P / T_sink
    return P * (1.0 / T_sink - alpha / T_source)


def _leg_wex_vec(
    P: np.ndarray,
    T_sink: np.ndarray,
    T_source: Optional[np.ndarray],
    carrier: str,
) -> np.ndarray:
    """Vectorised exergy.  Petela for radiation_bb, Carnot for heat."""
    if carrier in ("work", "chemical"):
        return P.copy()
    if T_source is None:
        return np.zeros_like(P)
    if carrier == "radiation_bb":
        r = T_sink / T_source
        # Petela exergy factor: (1 - (4/3)*r + (1/3)*r^4)
        return P * (1.0 - (4.0 / 3.0) * r + (1.0 / 3.0) * r ** 4)
    # Default: Carnot
    return P * (1.0 - T_sink / T_source)


# ===========================================================================
# Shared statistics helper (used by both per-leg and system-level MC)
# ===========================================================================
def _ci_block(arr: np.ndarray, lo_pct: float, hi_pct: float) -> Dict[str, float]:
    """Compute mean, median, std, CI, and relative uncertainty for an array."""
    mean = float(np.mean(arr))
    std = float(np.std(arr))
    return {
        "mean": mean, "median": float(np.median(arr)), "std": std,
        "ci_lower": float(np.percentile(arr, lo_pct)),
        "ci_upper": float(np.percentile(arr, hi_pct)),
        "relative_uncertainty_pct": float(std / (abs(mean) + 1e-300) * 100),
    }


# ===========================================================================
# Uncertainty metadata extraction
# ===========================================================================
def _extract_leg_uncertainty(
    leg: Dict[str, Any],
    carrier: str = "",
    regime: str = "",
) -> Dict[str, Dict[str, Any]]:
    """Extract uncertainty metadata from a leg dict.

    Distribution type is now assigned by _sample_param's physical rules,
    NOT taken from the JSON (which may declare "normal" for a temperature,
    which is wrong).  The JSON distribution field is preserved as
    'user_declared_distribution' for audit purposes only.
    """
    unc = leg.get("uncertainty") or {}
    result: Dict[str, Dict[str, Any]] = {}
    for param in ("P_W", "T_source_K", "T_sink_K", "eta_use"):
        nominal = leg.get(param)
        if nominal is None:
            continue
        # eta_use with no uncertainty block and value == 1.0 means
        # "ideal, no uncertainty to propagate" — skip rather than
        # imputing 5% fallback on a definitional 1.0.
        if param == "eta_use" and param not in unc and float(nominal) == 1.0:
            continue
        meta = unc.get(param) or {}
        user_dist = str(meta.get("distribution", ""))
        correct_dist = select_distribution(param, carrier, regime) if _MC_DIST_AVAILABLE else "normal"
        result[param] = {
            "value":                    float(meta.get("value", nominal)),
            "uncertainty_pct":          float(meta.get("uncertainty_pct", _DEFAULT_UNCERTAINTY_PCT)),
            "distribution":             correct_dist,
            "user_declared_distribution": user_dist or "(not declared)",
            "distribution_overridden":  bool(user_dist and user_dist != correct_dist),
            "source_quality":           str(meta.get("source_quality", "unknown")),
            "warned_fallback":          param not in unc,
        }
    return result


# ===========================================================================
# Per-leg Monte Carlo
# ===========================================================================
def monte_carlo_leg(
    leg: Dict[str, Any],
    n_samples: int = 10_000,
    rng: Optional[np.random.Generator] = None,
    regime: str = "",
    confidence_level: float = 0.95,
) -> Dict[str, Any]:
    """Run Monte Carlo propagation for a single carrier leg.

    Uses regime-aware, physically-correct distributions for all parameters.
    Canonical alpha values are FIXED -- not sampled.
    Physical constraint violations are reported explicitly, not silently clipped.

    Returns the result dict AND raw sample arrays (keyed with '_' prefix)
    so that monte_carlo_system can aggregate without re-sampling.
    """
    if rng is None:
        rng = np.random.default_rng()

    carrier = _canonical_name(leg.get("carrier", "work"))
    unc_meta = _extract_leg_uncertainty(leg, carrier, regime)
    warnings: List[str] = []

    for param, meta in unc_meta.items():
        if meta["warned_fallback"]:
            warnings.append(
                f"{leg.get('leg_id','?')}.{param}: no uncertainty declared; "
                f"using {_DEFAULT_UNCERTAINTY_PCT}% fallback"
            )
        if meta["distribution_overridden"]:
            warnings.append(
                f"{leg.get('leg_id','?')}.{param}: JSON declared distribution="
                f"'{meta['user_declared_distribution']}', overridden to "
                f"'{meta['distribution']}' (physically correct for this parameter "
                f"type)"
            )

    # --- ALPHA: for canonical carriers, fixed. Not sampled. ---
    raw_alpha = float(leg.get("alpha", leg.get("alpha_eff", 0.0)))
    alpha = alpha_for_mc(carrier, raw_alpha)  # returns canonical value for canonical carriers

    # --- Sample P, T_sink, T_source ---
    P_meta = unc_meta["P_W"]
    P_s = _sample_param("P_W", P_meta["value"], P_meta["uncertainty_pct"],
                        n_samples, rng, carrier, regime)

    T_snk_meta = unc_meta.get("T_sink_K")
    T_snk_s = (
        _sample_param("T_sink_K", T_snk_meta["value"], T_snk_meta["uncertainty_pct"],
                       n_samples, rng, carrier, regime)
        if T_snk_meta else np.full(n_samples, float(leg["T_sink_K"]))
    )

    T_src_meta = unc_meta.get("T_source_K")
    T_src_s: Optional[np.ndarray] = None
    if T_src_meta:
        T_src_s = _sample_param("T_source_K", T_src_meta["value"],
                                T_src_meta["uncertainty_pct"],
                                n_samples, rng, carrier, regime)

    # --- Physical constraint audit (before clamp) ---
    T_0_K = leg.get("T_0_K") or leg.get("system_T_0_K")
    T_0_s = np.full(n_samples, float(T_0_K)) if T_0_K else None

    # Run constraint audit even when mc_distributions is not available.
    # The old code skipped this entirely in fallback mode.
    if T_src_s is not None:
        if _MC_DIST_AVAILABLE:
            violations = check_physical_constraints(P_s, T_src_s, T_snk_s, T_0_s)
            severity, v_msg = interpret_constraint_violations(violations)
        else:
            # Minimal fallback constraint check
            neg_P = float(np.mean(P_s < 0))
            imp_ex = float(np.mean(T_src_s <= T_snk_s))
            any_inv = float(np.mean((P_s < 0) | (T_src_s <= T_snk_s)))
            violations = {
                "any_invalid_frac": any_inv,
                "impossible_exergy_frac": imp_ex,
                "negative_power_frac": neg_P,
                "below_dead_state_frac": 0.0,
            }
            severity = "error" if any_inv >= 0.10 else ("warn" if any_inv >= 0.01 else "ok")
            v_msg = f"{any_inv*100:.1f}% invalid draws (fallback audit)" if severity != "ok" else ""

        if severity != "ok":
            warnings.append(f"[{severity.upper()}] {v_msg}")
    else:
        violations = {"any_invalid_frac": 0.0, "impossible_exergy_frac": 0.0,
                      "negative_power_frac": 0.0, "below_dead_state_frac": 0.0}

    # --- Compute derived quantities ---
    ndot_raw = _leg_ndot_vec(P_s, T_snk_s, T_src_s, alpha)
    ndot_clamped = np.maximum(ndot_raw, 0.0)
    wex_raw = _leg_wex_vec(P_s, T_snk_s, T_src_s, carrier)
    wex_clamped = np.maximum(wex_raw, 0.0)

    # --- Sample eta_use if it has declared uncertainty ---
    eta_meta = unc_meta.get("eta_use")
    if eta_meta:
        eta_s = _sample_param("eta_use", eta_meta["value"],
                              eta_meta["uncertainty_pct"],
                              n_samples, rng, carrier, regime)
        # eta_use modulates usable exergy, not raw thermodynamic exergy.
        # Ndot (entropy production rate) is independent of utilization efficiency.
        wex_clamped = wex_clamped * eta_s
    else:
        eta_nom = float(leg.get("eta_use", 1.0))
        eta_s = np.full(n_samples, eta_nom)
        if eta_nom < 1.0:
            # Deterministic eta_use < 1: apply but don't sample
            wex_clamped = wex_clamped * eta_nom

    with np.errstate(divide="ignore", invalid="ignore"):
        eta_exergy_s = np.where(P_s > 0, wex_clamped / P_s, 0.0)

    bits_s = ndot_clamped * BITS_PER_J_PER_K

    # --- Statistics blocks ---
    lo_pct = (1.0 - confidence_level) / 2.0 * 100.0
    hi_pct = 100.0 - lo_pct

    return {
        "leg_id": leg.get("leg_id", "?"),
        "carrier": carrier,
        "alpha_used": float(alpha),
        "alpha_is_canonical_fixed": (carrier != "radiation_spectral"),
        "distribution_types": {p: m["distribution"] for p, m in unc_meta.items()},
        "physical_constraint_audit": violations,
        "n_samples": n_samples,
        "confidence_level": confidence_level,
        "Ndot_clamped_J_per_K_s": _ci_block(ndot_clamped, lo_pct, hi_pct),
        "W_ex_clamped_W": _ci_block(wex_clamped, lo_pct, hi_pct),
        "eta_exergy": _ci_block(eta_exergy_s, lo_pct, hi_pct),
        "bits_per_s": _ci_block(bits_s, lo_pct, hi_pct),
        "clamp_fraction": float(np.mean(ndot_raw < 0.0)),
        "warnings": warnings,
        # Raw arrays for system-level aggregation (not serialised to JSON)
        "_Ndot_raw": ndot_raw,
        "_W_ex_raw": wex_raw,
        "_W_ex_clamped": wex_clamped,
        "_P_s": P_s,
        "_Ndot_clamped": ndot_clamped,
        "_eta_s": eta_s,
    }


# ===========================================================================
# System-level Monte Carlo
# ===========================================================================
def monte_carlo_system(
    system: Dict[str, Any],
    n_samples: int = 10_000,
    confidence_level: float = 0.95,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Run Monte Carlo uncertainty propagation for an entire thermodynamic system.

    Samples all leg inputs jointly using a SINGLE RNG pass, sums Ndot and W_ex
    across legs, then computes system-level efficiency distribution.

    CRITICAL FIX (v1.5): The old code ran two independent passes — one for
    per-leg results and a second with rng2=default_rng(seed) for system
    aggregation.  While the draws were nominally identical, any divergence
    in RNG consumption between the two passes would silently decorrelate
    per-leg and system statistics, making the sensitivity analysis (Pearson r)
    meaningless.  Now we do a single pass: monte_carlo_leg returns raw sample
    arrays, and we aggregate them directly.

    Args:
        system:           System dict from data.json (with uncertainty metadata).
        n_samples:        MC sample count. 10k is usually sufficient.
        confidence_level: CI coverage probability (default 0.95).
        seed:             Random seed for reproducibility.

    Returns:
        Full uncertainty report dict including per-leg and system totals.
    """
    t0 = time.perf_counter()
    rng = np.random.default_rng(seed)

    legs = system.get("carrier_legs") or []
    if not legs:
        return {"status": "no_legs", "message": "System has no carrier legs."}

    regime = system.get("regime", "")

    # --- T0 handling: warn if defaulting ---
    T0_declared = system.get("dead_state_T0_K")
    system_warnings: List[str] = []
    if T0_declared is None:
        T0_sys = 298.15
        system_warnings.append(
            "dead_state_T0_K not declared in system. Defaulting to 298.15 K. "
            "This is WRONG for astrophysical systems (should be T_CMB = 2.725 K) "
            "and will silently inflate every exergy calculation. "
            "Declare dead_state_T0_K explicitly."
        )
    else:
        T0_sys = float(T0_declared)

    # Inject system T0 into each leg so per-leg constraint audit can use it
    for leg in legs:
        if "system_T_0_K" not in leg:
            leg["system_T_0_K"] = T0_sys

    # --- Single-pass: per-leg results with raw arrays ---
    leg_results = [
        monte_carlo_leg(leg, n_samples=n_samples, rng=rng, regime=regime,
                        confidence_level=confidence_level)
        for leg in legs
    ]

    # --- System-level aggregation from the SAME draws (no re-sampling) ---
    ndot_arrays = [lr["_Ndot_raw"] for lr in leg_results]
    wex_arrays = [lr["_W_ex_clamped"] for lr in leg_results]
    p_arrays = [lr["_P_s"] for lr in leg_results]

    ndot_sum_raw = np.sum(ndot_arrays, axis=0)
    ndot_sum_clamped = np.maximum(ndot_sum_raw, 0.0)
    wex_sum_clamped = np.maximum(np.sum(wex_arrays, axis=0), 0.0)

    # --- System efficiency: exergy_out / P_input ---
    # Use declared P_input_W if available (the thermodynamic input power).
    # Otherwise, sum all leg powers — but document this as "total leg power"
    # which may include both input and output legs.
    P_input_declared = system.get("P_input_W")
    if P_input_declared is not None:
        # Sample P_input with same uncertainty framework
        p_input_unc = system.get("uncertainty", {}).get("P_input_W", {})
        p_input_val = float(p_input_unc.get("value", P_input_declared))
        p_input_pct = float(p_input_unc.get("uncertainty_pct", 0.0))
        if p_input_pct > 0 and _MC_DIST_AVAILABLE:
            p_total_arr = sample_power(p_input_val, p_input_pct, n_samples, rng)
        else:
            p_total_arr = np.full(n_samples, float(P_input_declared))
        eta_denominator = "P_input_W"
    else:
        # Fallback: sum all leg powers (may include output legs)
        p_total_arr = sum(p_arrays)
        eta_denominator = "sum_all_legs"
        system_warnings.append(
            "eta_system denominator is sum of all leg powers (no P_input_W declared). "
            "For systems with both input and output legs, this underestimates efficiency. "
            "Declare P_input_W at the system level for correct eta."
        )

    with np.errstate(divide="ignore", invalid="ignore"):
        eta_sys = np.where(p_total_arr > 0, wex_sum_clamped / p_total_arr, 0.0)

    bits_sys = ndot_sum_clamped * BITS_PER_J_PER_K

    lo_pct = (1.0 - confidence_level) / 2.0 * 100.0
    hi_pct = 100.0 - lo_pct

    # --- Sensitivity: Spearman rank correlation ---
    # Spearman captures monotonic nonlinear relationships (e.g., the r⁴ term
    # in Petela exergy) more faithfully than Pearson r.  For the small
    # uncertainty ranges typical here (1-5%), the difference is minor, but
    # Spearman is strictly more defensible for a general sensitivity analysis.
    sensitivities: Dict[str, float] = {}
    for i, leg in enumerate(legs):
        leg_id = leg.get("leg_id", f"leg{i}")
        rho = float(stats.spearmanr(ndot_arrays[i], ndot_sum_raw).statistic)
        sensitivities[f"{leg_id}_Ndot_vs_system"] = rho

    # --- Strip raw arrays from per-leg results before returning ---
    clean_leg_results = []
    for lr in leg_results:
        clean = {k: v for k, v in lr.items() if not k.startswith("_")}
        clean_leg_results.append(clean)

    # Collect all per-leg warnings into system warnings
    for lr in clean_leg_results:
        for w in lr.get("warnings", []):
            system_warnings.append(f"[{lr['leg_id']}] {w}")

    elapsed = time.perf_counter() - t0

    return {
        "status": "ok",
        "n_samples": n_samples,
        "confidence_level": confidence_level,
        "system_totals": {
            "Ndot_J_per_K_s": _ci_block(ndot_sum_clamped, lo_pct, hi_pct),
            "Ndot_raw_J_per_K_s": _ci_block(ndot_sum_raw, lo_pct, hi_pct),
            "W_ex_W": _ci_block(wex_sum_clamped, lo_pct, hi_pct),
            "eta_system": _ci_block(eta_sys, lo_pct, hi_pct),
            "eta_denominator": eta_denominator,
            "bits_per_s": _ci_block(bits_sys, lo_pct, hi_pct),
            "clamp_fraction": float(np.mean(ndot_sum_raw < 0.0)),
        },
        "per_leg": clean_leg_results,
        "sensitivity": sensitivities,
        "warnings": system_warnings,
        "computational_cost": {
            "n_samples": n_samples,
            "n_legs": len(legs),
            "runtime_seconds": round(elapsed, 3),
        },
        "runtime_provenance": {
            "engine_version": __version__,
            "mc_distributions_available": _MC_DIST_AVAILABLE,
            "carrier_constants_available": _CARRIER_CONST_AVAILABLE,
            "distribution_backend": "mc_distributions (regime-aware)" if _MC_DIST_AVAILABLE
                                    else "fallback (Gaussian only)",
        },
    }


# ===========================================================================
# Pretty-printer
# ===========================================================================
def print_mc_report(result: Dict[str, Any], system_name: str = "") -> None:
    """Pretty-print a Monte Carlo result dict to stdout."""
    sep = "=" * 68
    print(sep)
    title = f"  MONTE CARLO UNCERTAINTY REPORT"
    if system_name:
        title += f"  [{system_name}]"
    print(title)
    print(sep)

    if result.get("status") != "ok":
        print(f"  Status: {result.get('status')} {result.get('message','')}")
        return

    cc = result["computational_cost"]
    cl_pct = int(result["confidence_level"] * 100)
    print(
        f"  Samples: {cc['n_samples']:,}  "
        f"Legs: {cc['n_legs']}  "
        f"Runtime: {cc['runtime_seconds']} s  "
        f"CI: {cl_pct}%"
    )
    print()

    st = result["system_totals"]
    print("  SYSTEM TOTALS")
    hdr = f"  {'Quantity':<28} {'Mean':>14} {f'{cl_pct}% CI':>30} {'Rel.Unc':>10}"
    print(hdr)
    print("  " + "-" * 84)

    def row(label: str, block: Dict[str, float], fmt: str = ".4g") -> None:
        mean = block["mean"]
        lo = block.get("ci_lower", block.get("ci_lower_95", float("nan")))
        hi = block.get("ci_upper", block.get("ci_upper_95", float("nan")))
        ru = block["relative_uncertainty_pct"]
        ci_str = f"[{lo:{fmt}}, {hi:{fmt}}]"
        mean_str = format(mean, fmt)
        print(f"  {label:<28} {mean_str:>14} {ci_str:>30} {ru:>7.1f}%")

    row("Ndot (J/K/s)", st["Ndot_J_per_K_s"])
    row("W_ex (W)", st["W_ex_W"])
    row("eta_system", st["eta_system"], ".4f")
    row("bits/s (Landauer)", st["bits_per_s"])

    cf = st["clamp_fraction"]
    if cf > 0:
        print(f"\n  WARNING: Clamp fired in {cf*100:.1f}% of samples (Ndot_raw < 0)")

    print()
    print("  PER-LEG")
    for leg_r in result["per_leg"]:
        lid = leg_r["leg_id"]
        nd = leg_r["Ndot_clamped_J_per_K_s"]
        eta = leg_r["eta_exergy"]
        cf_leg = leg_r["clamp_fraction"]
        print(f"  [{lid}]")
        print(
            f"      Ndot  mean={nd['mean']:.4g}  "
            f"{cl_pct}%CI=[{nd['ci_lower']:.4g}, {nd['ci_upper']:.4g}]  "
            f"relUnc={nd['relative_uncertainty_pct']:.1f}%"
        )
        print(
            f"      eta   mean={eta['mean']:.4f}  "
            f"{cl_pct}%CI=[{eta['ci_lower']:.4f}, {eta['ci_upper']:.4f}]"
        )
        if cf_leg > 0:
            print(f"      WARNING: Clamp fired in {cf_leg*100:.1f}% of leg samples")
        for w in leg_r.get("warnings", []):
            print(f"      NOTE: {w}")

    # Warnings
    if result.get("warnings"):
        print()
        print("  WARNINGS")
        for w in result["warnings"]:
            print(f"    {w}")

    print()
    print("  SENSITIVITY  (Pearson r: leg Ndot vs system Ndot)")
    for k, v in result["sensitivity"].items():
        print(f"    {k:<48} {v:+.4f}")

    print(sep)


# ===========================================================================
# CLI deep-audit mode
# ===========================================================================
def deep_audit_mode(
    system_name: str,
    data_path: str,
    n_samples: int = 10_000,
    seed: Optional[int] = None,
) -> None:
    """CLI entry point for deep audit mode."""
    import json

    print("=" * 68)
    print("  DEEP AUDIT -- Monte Carlo Uncertainty Propagation")
    print("=" * 68)
    if n_samples > 100_000:
        print(f"  WARNING: {n_samples:,} samples may be slow.")
    print()

    with open(data_path) as f:
        data = json.load(f)

    sysobj = data.get("real_systems", {}).get(system_name)
    if sysobj is None:
        for bh in data.get("black_holes") or []:
            if bh.get("label") == system_name:
                sysobj = bh
                break

    if sysobj is None:
        print(f"  ERROR: '{system_name}' not found in {data_path}")
        return

    result = monte_carlo_system(sysobj, n_samples=n_samples, seed=seed)
    print_mc_report(result, system_name=system_name)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Monte Carlo uncertainty propagation")
    parser.add_argument("data_path", help="Path to data.json")
    parser.add_argument("system", help="System name or BH label")
    parser.add_argument("--samples", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    deep_audit_mode(args.system, args.data_path, n_samples=args.samples, seed=args.seed)
