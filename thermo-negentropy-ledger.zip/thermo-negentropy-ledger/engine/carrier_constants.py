"""carrier_constants.py - canonical alpha values as Second Law structural constants.

Every carrier type has an exact, analytically-derived alpha that enters the
negentropy flux as  Ndot = P * (1/T_sink - alpha/T_source).

These are NOT tunable parameters.  They are consequences of the Second Law
for each energy-carrier class:

    work / chemical:      alpha = 0   (ideal available work definition)
    heat:                 alpha = 1   (Clausius inequality, exact)
    radiation_bb:         alpha = 4/3 (Petela 1964, blackbody optically thick)
    radiation_spectral:   alpha in [0, 4/3]  (bounded by Petela limit)

References:
    Petela, R. (1964). Exergy of heat radiation. J. Heat Transfer 86(2), 187-192.
    Clausius, R. (1865). Mechanical Theory of Heat.
"""
import math
from typing import Dict, List, Optional, Tuple

__version__ = "1.5.0"

# ---------------------------------------------------------------------------
# Canonical alpha dictionary — exact analytical values
# ---------------------------------------------------------------------------
CANONICAL_ALPHA: Dict[str, float] = {
    "work":         0.0,            # ideal available work: no entropy exchange
    "chemical":     0.0,            # Gibbs free energy ideal limit
    "heat":         1.0,            # Clausius inequality — exact, not negotiable
    "radiation_bb": 4.0 / 3.0,     # Petela (1964) blackbody entropy flux (4/3)*P/T
}

# Spectral (non-blackbody) radiation: alpha genuinely varies in [0, 4/3].
# It is the ONLY carrier whose alpha is a measured/modeled quantity.
RADIATION_SPECTRAL_ALPHA_BOUNDS: Tuple[float, float] = (0.0, 4.0 / 3.0)

# ---------------------------------------------------------------------------
# Carrier name resolution
# ---------------------------------------------------------------------------
_CARRIER_ALIASES: Dict[str, str] = {
    "electricity": "work",
    "mechanical":  "work",
    "electric":    "work",
    "shaft":       "work",
    "shaft_work":  "work",
}

# Tolerance for floating-point comparison of declared vs canonical alpha.
# 1e-9 is ~8 orders below any meaningful alpha difference.
_ALPHA_TOL: float = 1e-9

_KNOWN_CARRIERS = set(CANONICAL_ALPHA.keys()) | {"radiation_spectral"}


def canonical_name(carrier: str) -> str:
    """Resolve a carrier string to its canonical name.

    Raises ValueError for truly unknown carriers.
    """
    c = carrier.strip().lower()
    resolved = _CARRIER_ALIASES.get(c, c)
    if resolved not in _KNOWN_CARRIERS:
        raise ValueError(
            f"Unknown carrier: {carrier!r}. "
            f"Known: {sorted(_KNOWN_CARRIERS)}"
        )
    return resolved


def canonical_alpha(carrier: str) -> Optional[float]:
    """Return the canonical alpha for a carrier, or None for radiation_spectral."""
    return CANONICAL_ALPHA.get(canonical_name(carrier))


def enforce_canonical_alpha(carrier, declared_alpha, leg_id="?", strict=True):
    """Validate that a declared alpha matches the canonical value.

    Returns (ok: bool, message: str).
    For radiation_spectral, checks Petela bounds [0, 4/3].
    For canonical carriers, checks exact match within _ALPHA_TOL.
    """
    try:
        name = canonical_name(carrier)
    except ValueError as e:
        msg = str(e)
        if strict:
            raise ValueError(f"Leg {leg_id!r}: {msg}")
        return False, msg

    # --- radiation_spectral: bounded but not fixed ---
    if name == "radiation_spectral":
        lo, hi = RADIATION_SPECTRAL_ALPHA_BOUNDS
        if not (lo - _ALPHA_TOL <= declared_alpha <= hi + _ALPHA_TOL):
            msg = (
                f"Leg {leg_id!r}: radiation_spectral alpha={declared_alpha:.6f} "
                f"outside [{lo:.4f}, {hi:.6f}]. Cannot exceed Petela limit 4/3"
            )
            if strict:
                raise ValueError(msg)
            return False, msg
        return True, ""

    # --- Canonical carriers: exact match required ---
    expected = CANONICAL_ALPHA[name]
    if abs(declared_alpha - expected) > _ALPHA_TOL:
        notes = {
            "work":         "alpha=0 for work is the ideal available work definition. "
                            "Use carrier='heat' if entropy is exchanged.",
            "chemical":     "alpha=0 for chemical is the Gibbs free energy ideal limit.",
            "heat":         "alpha=1 for heat is the Clausius inequality — exact. Not a "
                            "fit parameter.",
            "radiation_bb": ("alpha=4/3 for radiation_bb is the Petela (1964) result for "
                             "entropy flux (4/3)*P/T. Not a fit parameter. "
                             "Use radiation_spectral for non-blackbody spectra."),
        }
        msg = (
            f"Leg {leg_id!r}: carrier={carrier!r} declares alpha={declared_alpha}. "
            f"Required canonical value is alpha={expected}. "
            f"This is a Second Law structural constant, not a user parameter. "
            f"{notes.get(name, '')}"
        )
        if strict:
            raise ValueError(msg)
        return False, msg

    return True, ""


def validate_all_legs(legs, strict=True):
    """Validate alpha declarations for all carrier legs."""
    all_ok, errors = True, []
    for leg in legs:
        carrier = leg.get("carrier", "")
        alpha = float(leg.get("alpha", leg.get("alpha_eff", 0.0)))
        ok, msg = enforce_canonical_alpha(
            carrier, alpha, leg.get("leg_id", "?"), strict=strict
        )
        if not ok:
            all_ok = False
            errors.append(msg)
    return all_ok, errors


def alpha_for_mc(carrier: str, declared_alpha: float) -> float:
    """Return the operative alpha for Monte Carlo sampling.

    For canonical carriers (work, chemical, heat, radiation_bb):
        Returns the exact canonical value — NOT the declared value.
        These have zero epistemic uncertainty; sampling them is a category error.

    For radiation_spectral:
        Returns the declared alpha_eff (genuinely uncertain, bounded [0, 4/3]).
    """
    name = canonical_name(carrier)
    if name == "radiation_spectral":
        return declared_alpha
    return CANONICAL_ALPHA[name]
