"""mc_distributions.py

Regime-aware, physically-correct distribution selection for Monte Carlo
uncertainty propagation in the Negentropy Ledger.

THE PROBLEM WITH NAIVE GAUSSIAN SAMPLING:

 1. Efficiencies (eta_use) are bounded [0,1].  A Gaussian at 0.85 with 10%
    uncertainty produces draws above 1.0.  Post-hoc clipping compresses the
    upper tail and biases the mean downward.  Bias is not disclosed.

 2. Temperatures must be strictly > 0 K.  Gaussian at 300 K with large sigma
    produces negative temperatures.  Clipping to ~0 biases the distribution
    toward the lower boundary.

 3. Power values have multiplicative uncertainty: a 10% calibration error
    is +/-10% of the actual value, not +/-10% of some reference.  Log-normal
    is the correct model for multiplicative errors on positive quantities.

 4. When T_source and T_sink are sampled independently as Gaussians, some
    draws will have T_source <= T_sink.  These are physically impossible for
    positive exergy.  Silent clipping biases exergy toward zero at the boundary.
    The correct approach: track the violation fraction and report it explicitly
    as a bias warning.  If it exceeds a threshold, the uncertainty spec itself
    is invalid (the nominal values are too close together given the declared
    uncertainty).

 5. Canonical carrier alpha values (heat=1, work=0, radiation_bb=4/3) are
    exact analytical derivations, not measurements.  They have zero epistemic
    uncertainty.  Sampling them introduces spurious uncertainty and is wrong.

THIS MODULE FIXES ALL FIVE:
    Efficiencies  -> Beta distribution, strictly bounded [0, 1]
    Temperatures  -> Truncated normal, physical lower bound enforced
    Power         -> Log-normal (multiplicative error model)
    Canon alphas  -> Fixed at canonical value, NOT sampled
    Constraints   -> Per-draw validity audit, violation fractions reported

REFERENCE:
    Saltelli et al. (2008). Global Sensitivity Analysis. Wiley.
    Jaynes (2003). Probability Theory. Cambridge University Press.
"""
import math
from typing import Dict, Optional, Tuple

import numpy as np
from scipy import stats

__version__ = "1.5.0"

# ===========================================================================
# Physical temperature floors by regime class
# ===========================================================================
# Fixsen, D.J. (2009). "The Temperature of the Cosmic Microwave Background."
# ApJ 707(2): 916-920.  T_CMB = 2.72548 +/- 0.00057 K.
# Rounded to 3 decimal places for readability; the truncation (0.00048 K)
# is within the 1-sigma measurement uncertainty.
T_FLOOR_CMB_K: float = 2.725

# Engineering cryogenic floor.  Below ~1 K you are in dilution-refrigerator
# territory; no macroscopic thermodynamic system operates below this as a
# sink or source temperature.  Conservative for Rankine/ORC/data-center use.
T_FLOOR_ENGINEERING_K: float = 1.0

# Numeric absolute floor to prevent division-by-zero in T ratios.
# Set at 1 microkelvin — six orders below any physical scenario but
# large enough to avoid IEEE subnormal arithmetic artifacts.
T_FLOOR_ABSOLUTE_K: float = 1e-6

# ===========================================================================
# Invalid-draw thresholds for physical constraint auditing
# ===========================================================================
# Fraction of MC draws violating physical constraints that triggers a warning.
# 1% means the tails of the declared uncertainty are reaching into unphysical
# territory.  The MC result carries moderate bias from boundary effects.
INVALID_DRAW_WARN_THRESHOLD: float = 0.01

# 10%: the uncertainty specification is likely wrong.  The nominal values
# are inconsistent with the declared uncertainty (e.g., T_source and T_sink
# are too close for the given sigma, or T_0_K is poorly constrained).
# The MC result should not be cited.
INVALID_DRAW_ERROR_THRESHOLD: float = 0.10


# ===========================================================================
# Log-normal parameter conversion
# ===========================================================================
def _lognormal_params(mean: float, rel_sigma: float) -> Tuple[float, float]:
    """Convert (mean, fractional_sigma) to log-normal (mu_ln, sigma_ln).

    rel_sigma is fractional, e.g. 0.10 for 10%.

    Derivation: If X ~ LogNormal(mu_ln, sigma_ln), then
        E[X] = exp(mu_ln + sigma_ln^2/2)
        Var[X] = (exp(sigma_ln^2) - 1) * exp(2*mu_ln + sigma_ln^2)

    Given E[X] = mean and Var[X] = (mean * rel_sigma)^2:
        sigma_ln = sqrt(ln(1 + rel_sigma^2))           [exact]
        mu_ln    = ln(mean) - sigma_ln^2 / 2           [exact]

    Note: for small rel_sigma, sigma_ln ≈ rel_sigma (first-order).
    """
    var = (mean * rel_sigma) ** 2
    sigma_ln = math.sqrt(math.log(1.0 + var / mean ** 2))
    mu_ln = math.log(mean) - 0.5 * sigma_ln ** 2
    return mu_ln, sigma_ln


# ===========================================================================
# Beta distribution parameter conversion
# ===========================================================================
def _beta_params(mean: float, rel_sigma: float) -> Tuple[float, float]:
    """Convert (mean, fractional_sigma) to Beta(a, b) parameters.

    mean must be in (0, 1).  Clamps variance to prevent degenerate cases.

    Derivation: If X ~ Beta(a, b), then
        E[X] = a / (a + b) = mean
        Var[X] = a*b / ((a+b)^2 * (a+b+1))

    Solving:
        factor = mean*(1-mean)/var - 1
        a = mean * factor
        b = (1-mean) * factor

    Requires var < mean*(1-mean) for valid (a,b > 0).
    """
    # Clamp mean away from exact 0 or 1 to keep Beta well-defined.
    # 1e-4 from each boundary: smallest meaningful efficiency difference.
    mean = float(np.clip(mean, 1e-4, 1.0 - 1e-4))
    sigma = mean * rel_sigma

    # Maximum variance for Beta is mean*(1-mean) when a+b -> 0 (uniform limit).
    # We clamp requested variance to 99% of this maximum to keep a,b >= ~0.01.
    # The 0.99 factor prevents the degenerate a+b -> 0 limit where Beta
    # becomes bimodal (U-shaped) which is unphysical for efficiency estimates.
    var_max = mean * (1.0 - mean)
    var = min(sigma ** 2, var_max * 0.99)

    # If variance is negligibly small, return a point mass.
    # 1e-14 threshold: below this, Beta(a,b) parameters exceed ~1e6 and
    # sampling becomes numerically indistinguishable from the mean.
    if var < 1e-14:
        return 1e6, 1e6  # effectively a point mass at mean ≈ 0.5

    factor = mean * (1.0 - mean) / var - 1.0

    # Floor a,b at 1e-3 to prevent extreme U-shaped distributions.
    # Beta(a,b) with a or b < 0.01 produces probability mass piled at 0 or 1,
    # which is unphysical for an efficiency parameter.  1e-3 keeps the
    # distribution unimodal for any mean in [0.01, 0.99].
    a = max(mean * factor, 1e-3)
    b = max((1.0 - mean) * factor, 1e-3)
    return a, b


# ===========================================================================
# Sampling functions
# ===========================================================================
def sample_temperature(
    mean_K: float,
    uncertainty_pct: float,
    n: int,
    rng: np.random.Generator,
    t_floor_K: float = T_FLOOR_ABSOLUTE_K,
) -> np.ndarray:
    """Sample temperature using truncated normal distribution.

    Lower bound enforced at t_floor_K (physical minimum for the regime).
    Upper bound unconstrained.

    Args:
        mean_K:          Nominal temperature in Kelvin.
        uncertainty_pct: Percentage uncertainty (1-sigma), e.g. 5.0 for 5%.
        n:               Number of samples.
        rng:             NumPy Generator for reproducibility.
        t_floor_K:       Physical lower bound (CMB for astrophysics, ~1K for engi-
                         neering systems, 1e-6 K numeric floor).

    Returns:
        Array of n positive temperature samples in Kelvin.
    """
    sigma = mean_K * (uncertainty_pct / 100.0)
    # Zero or negligible uncertainty: return constant array.
    # 1e-12 threshold: at this relative precision, truncation effects are
    # unmeasurable (~1 part per trillion).
    if sigma < 1e-12:
        return np.full(n, mean_K)
    a = (t_floor_K - mean_K) / sigma   # lower truncation point (in sigma units)
    return stats.truncnorm.rvs(a=a, b=np.inf, loc=mean_K, scale=sigma,
                               size=n, random_state=rng)


def sample_power(
    mean_W: float,
    uncertainty_pct: float,
    n: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Sample power using log-normal distribution (multiplicative error model).

    Power uncertainty is typically a calibration fraction of the true value,
    not an additive offset.  Log-normal correctly models this and guarantees
    all samples are strictly positive.

    Args:
        mean_W:          Nominal power in Watts.
        uncertainty_pct: Percentage uncertainty (1-sigma), e.g. 2.0 for 2%.

    Returns:
        Array of n positive power samples in Watts.
    """
    # Zero uncertainty or non-positive power: return constant.
    if uncertainty_pct < 1e-9 or mean_W <= 0:
        return np.full(n, max(mean_W, 0.0))
    mu_ln, sigma_ln = _lognormal_params(mean_W, uncertainty_pct / 100.0)
    return rng.lognormal(mean=mu_ln, sigma=sigma_ln, size=n)


def sample_efficiency(
    mean: float,
    uncertainty_pct: float,
    n: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Sample dimensionless efficiency (eta_use) using Beta distribution.

    Beta is the natural distribution for quantities bounded to [0, 1].
    No clipping required or performed — all samples are in [0, 1] by construction.

    Args:
        mean:            Nominal efficiency in [0, 1].
        uncertainty_pct: Percentage uncertainty, e.g. 10.0 for 10%.

    Returns:
        Array of n efficiency samples in [0, 1].
    """
    if uncertainty_pct < 1e-9:
        return np.full(n, np.clip(mean, 0.0, 1.0))
    a, b = _beta_params(float(mean), uncertainty_pct / 100.0)
    # If _beta_params returned a near-degenerate point mass (a >= 1e5),
    # skip sampling and return the constant.  This threshold matches the
    # point-mass return (1e6, 1e6) from _beta_params — any (a,b) above 1e5
    # produces a distribution with std < 0.001, indistinguishable from fixed.
    if a > 1e5:
        return np.full(n, np.clip(mean, 0.0, 1.0))  # degenerate: point mass
    return rng.beta(a, b, size=n)


# ===========================================================================
# Physical constraint auditing
# ===========================================================================
def check_physical_constraints(
    P_s: np.ndarray,
    T_src_s: Optional[np.ndarray],
    T_snk_s: np.ndarray,
    T_0_s: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    """Per-draw physical validity audit.  Returns violation fractions, not clipped draws.

    Violations tracked:
        negative_power_frac:     P_s < 0   (should be ~0 with log-normal)
        impossible_exergy_frac:  T_src <= T_snk  (Carnot eta <= 0 — exergy impossible)
        below_dead_state_frac:   T_snk < T_0     (below dead state — unphysical sink)
        any_invalid_frac:        union of all above
    """
    neg_P = np.mean(P_s < 0)

    impossible_ex = 0.0
    if T_src_s is not None:
        impossible_ex = float(np.mean(T_src_s <= T_snk_s))

    below_dead = 0.0
    if T_0_s is not None:
        # When T_sink is nominally AT the dead state (which is common —
        # e.g., data center rejecting to ambient = dead state), MC sampling
        # will put ~50% of draws below T_0. That's expected noise, not a
        # physics violation. Use the declared uncertainty width as the
        # tolerance: if the nominal T_sink is within 1σ of T_0, the
        # below-dead fraction is informational only, not a violation.
        #
        # For legs where T_sink is genuinely below T_0 (which would be
        # unphysical — heat flowing to below-dead-state), the nominal gap
        # will be large relative to uncertainty and this fires correctly.
        T_0_mean = float(np.mean(T_0_s))
        T_snk_mean = float(np.mean(T_snk_s))
        T_snk_std = float(np.std(T_snk_s))
        # If nominal T_sink is within 2σ of T_0, treat below-dead as
        # informational (sink IS the dead state, sampling noise expected)
        nominal_gap = T_snk_mean - T_0_mean
        sink_is_dead_state = abs(nominal_gap) < 2.0 * max(T_snk_std, 1e-10)
        if not sink_is_dead_state:
            below_dead = float(np.mean(T_snk_s < T_0_s * (1.0 - 1e-9)))

    if T_src_s is not None and T_0_s is not None:
        # Use below_dead (already computed with sink≈T0 tolerance)
        below_mask = np.zeros(len(P_s), dtype=bool)
        if below_dead > 0:
            below_mask = T_snk_s < T_0_s * (1.0 - 1e-9)
        any_inv = float(np.mean(
            (P_s < 0) | (T_src_s <= T_snk_s) | below_mask
        ))
    elif T_src_s is not None:
        any_inv = float(np.mean((P_s < 0) | (T_src_s <= T_snk_s)))
    elif T_0_s is not None:
        below_mask = np.zeros(len(P_s), dtype=bool)
        if below_dead > 0:
            below_mask = T_snk_s < T_0_s * (1.0 - 1e-9)
        any_inv = float(np.mean((P_s < 0) | below_mask))
    else:
        any_inv = float(neg_P)

    result = {
        "negative_power_frac":    float(neg_P),
        "impossible_exergy_frac": impossible_ex,
        "below_dead_state_frac":  below_dead,
        "any_invalid_frac":       any_inv,
    }

    # --- T-gap diagnostic: distinguish "T uncertainty too wide for gap"
    # from "physically inconsistent system" ---
    if T_src_s is not None:
        gap = T_src_s - T_snk_s
        gap_mean = float(np.mean(gap))
        gap_std = float(np.std(gap))
        # sigma_ratio: how many combined sigmas the nominal gap is wide.
        # < 3 means uncertainty spans the overlap zone routinely.
        result["T_gap_mean_K"] = gap_mean
        result["T_gap_std_K"] = gap_std
        result["T_gap_sigma_ratio"] = (gap_mean / gap_std) if gap_std > 1e-30 else float('inf')

    return result


def interpret_constraint_violations(violations: Dict[str, float]) -> Tuple[str, str]:
    """Return (severity, message) based on violation fractions.

    severity: "ok" | "warn" | "error"

    When T_gap diagnostic fields are present, distinguishes:
      - "T uncertainty too wide for gap": system is fine, but declared
        uncertainty_pct on temperatures is too large relative to the
        T_source − T_sink headroom.
      - "physically inconsistent system": the nominal T_source is not
        meaningfully above T_sink even at zero uncertainty.
    """
    frac = violations["any_invalid_frac"]
    imp_ex = violations["impossible_exergy_frac"]

    # --- Build T-gap diagnostic suffix when available ---
    gap_diag = ""
    sigma_ratio = violations.get("T_gap_sigma_ratio")
    if sigma_ratio is not None and imp_ex > 0.001:
        gap_mean = violations["T_gap_mean_K"]
        gap_std = violations["T_gap_std_K"]
        if gap_mean > 0 and sigma_ratio < 5.0:
            # Nominal gap is positive but small relative to combined uncertainty.
            # This is a declaration problem, not a physics problem.
            gap_diag = (
                f" Diagnosis: T_source − T_sink gap is {gap_mean:.1f} K "
                f"but combined 1σ uncertainty is {gap_std:.1f} K "
                f"(gap/σ = {sigma_ratio:.1f}). "
                "This is a T-uncertainty-too-wide problem: tighten "
                "temperature uncertainty_pct to reflect actual measurement "
                "precision, not total process uncertainty (which belongs in P_W)."
            )
        elif gap_mean <= 0:
            # Nominal T_source ≤ T_sink — the system itself is unphysical
            gap_diag = (
                f" Diagnosis: nominal T_source − T_sink = {gap_mean:.1f} K. "
                "The system is fundamentally inconsistent: T_source must "
                "exceed T_sink for positive exergy."
            )

    if frac >= INVALID_DRAW_ERROR_THRESHOLD:
        return "error", (
            f"{frac*100:.1f}% of MC draws are physically invalid "
            f"(impossible_exergy={imp_ex*100:.1f}%)."
            + gap_diag
        )
    elif frac >= INVALID_DRAW_WARN_THRESHOLD:
        return "warn", (
            f"{frac*100:.1f}% of MC draws are physically invalid "
            f"(impossible_exergy={imp_ex*100:.1f}%). "
            "MC result carries moderate bias from boundary effects. "
            "Reported CIs are conservative (narrowed on the physical side)."
            + gap_diag
        )
    return "ok", ""


# ===========================================================================
# Temperature floor by regime
# ===========================================================================
def t_floor_for_regime(regime: str) -> float:
    """Return physically appropriate temperature floor for a modeling regime."""
    astrophysics = {
        "astrophysics_stellar_surface",
        "astrophysics_stellar_interior",
        "astrophysics_neutron_star",
        "astrophysics_black_hole_hawking",
    }
    return T_FLOOR_CMB_K if regime in astrophysics else T_FLOOR_ENGINEERING_K


# ===========================================================================
# Distribution selection dispatch
# ===========================================================================
def select_distribution(param_name: str, carrier: str = "", regime: str = "") -> str:
    """Return the physically appropriate distribution type for a parameter.

    "lognormal" -> power (multiplicative uncertainty, always positive)
    "truncnorm" -> temperatures (additive uncertainty, bounded below)
    "beta"      -> efficiencies (bounded [0, 1])
    "fixed"     -> canonical alpha (exact derivation, zero uncertainty)
    "uniform"   -> radiation_spectral alpha_eff (bounded, genuinely uncertain)
    "normal"    -> fallback for undeclared parameter types
    """
    if param_name == "P_W":
        return "lognormal"
    if param_name in ("T_source_K", "T_sink_K", "T_0_K", "T_erase_K"):
        return "truncnorm"
    if param_name == "eta_use":
        return "beta"
    if param_name in ("alpha", "alpha_eff"):
        try:
            from carrier_constants import CANONICAL_ALPHA, canonical_name
            name = canonical_name(carrier) if carrier else ""
            if name in CANONICAL_ALPHA:
                return "fixed"
        except (ImportError, ValueError):
            pass
        return "uniform"    # radiation_spectral: uniform on [0, 4/3]
    return "normal"


# ===========================================================================
# Self-test
# ===========================================================================
if __name__ == "__main__":
    import sys
    rng = np.random.default_rng(42)
    n = 50_000

    print("=== Distribution tests (n=50,000) ===")
    print()

    # Temperature: truncated normal
    T_s = sample_temperature(300.0, 5.0, n, rng, t_floor_K=2.725)
    print(f"Temperature (truncnorm, mean=300K, 5%):")
    print(f"  min={T_s.min():.2f}  mean={T_s.mean():.2f}  max={T_s.max():.2f}  std={T_s.std():.2f}")
    assert T_s.min() > 0, "Temperature sample went negative!"

    # Power: log-normal
    P_s = sample_power(1e9, 2.0, n, rng)
    print(f"Power (lognormal, mean=1GW, 2%):")
    print(f"  min={P_s.min():.4e}  mean={P_s.mean():.4e}  std={P_s.std():.4e}")
    assert P_s.min() > 0, "Power sample went negative!"

    # Efficiency: beta
    eta_s = sample_efficiency(0.38, 10.0, n, rng)
    print(f"Efficiency (beta, mean=0.38, 10%):")
    print(f"  min={eta_s.min():.4f}  mean={eta_s.mean():.4f}  max={eta_s.max():.4f}  std={eta_s.std():.4f}")
    assert eta_s.min() >= 0 and eta_s.max() <= 1, "Efficiency out of [0,1]!"

    # Constraint audit
    T_src = sample_temperature(600.0, 5.0, n, rng)
    T_snk = sample_temperature(300.0, 5.0, n, rng)
    violations = check_physical_constraints(P_s, T_src, T_snk)
    severity, msg = interpret_constraint_violations(violations)
    print(f"Constraint audit (T_src=600K+/-5%, T_snk=300K+/-5%):")
    print(f"  impossible_exergy_frac={violations['impossible_exergy_frac']*100:.3f}%  severity={severity}")

    # Tight temperatures (should warn)
    T_src_tight = sample_temperature(305.0, 5.0, n, rng)
    T_snk_tight = sample_temperature(295.0, 5.0, n, rng)
    v2 = check_physical_constraints(P_s, T_src_tight, T_snk_tight)
    sev2, msg2 = interpret_constraint_violations(v2)
    print(f"Constraint audit (T_src=305K, T_snk=295K, both 5% unc):")
    print(f"  impossible_exergy_frac={v2['impossible_exergy_frac']*100:.1f}%  severity={sev2}")
    if msg2:
        print(f"  -> {msg2[:100]}")

    print()
    print("All distribution tests passed.")
