#!/usr/bin/env python3
"""
Build Thermo-negentropy-Ledger-v1.5.zip

Run from anywhere:  python3 build_zip.py
Output:             ./Thermo-negentropy-Ledger-v1.5.zip

Version is read from carrier_constants.__version__ so the zip name
cannot drift from the code it contains.
"""
import zipfile
import os
import sys

SRC = os.path.dirname(os.path.abspath(__file__))

# --- Version from single source of truth ---
try:
    # Add SRC to path so we can import carrier_constants
    sys.path.insert(0, SRC)
    from carrier_constants import __version__ as _pkg_version
except ImportError:
    _pkg_version = "1.5.0"
    print(f"[warn] carrier_constants not importable; using hardcoded {_pkg_version}",
          file=sys.stderr)

ZIP_NAME = f"Thermo-negentropy-Ledger-v{_pkg_version}.zip"
OUT = os.path.join(os.path.dirname(SRC), ZIP_NAME)
OUT = os.path.normpath(OUT)

SKIP_DIRS = {"__pycache__", ".pytest_cache", ".git"}
SKIP_EXTS = {".pyc", ".provenance.json"}

if not os.path.isdir(SRC):
    sys.exit(f"Source not found: {SRC}")

names = []
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in sorted(dirs) if d not in SKIP_DIRS]
        for fn in sorted(files):
            if any(fn.endswith(e) for e in SKIP_EXTS):
                continue
            fp = os.path.join(root, fn)
            arc = "Thermo-negentropy-Ledger/" + os.path.relpath(fp, SRC)
            zf.write(fp, arc)
            names.append(arc)

size_kb = os.path.getsize(OUT) // 1024
print(f"[OK] {OUT} ({size_kb} KB, {len(names)} files)")
for n in names:
    print(f"  {n}")
