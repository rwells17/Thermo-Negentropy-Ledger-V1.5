# data.json Patch Specification — v1.5

## 1. CMB T_sink_K → 3 decimal places for readability

All astrophysical systems using the CMB as sink should use `T_sink_K: 2.725`
(not `2.72548`). The truncation (0.00048 K) is within the Fixsen (2009) 1σ
measurement uncertainty of ±0.00057 K, so no physics is lost.

### Affected fields (search & replace):

```
System: Sun
  carrier_legs[0].T_sink_K:    2.725   → 2.725   (already correct)
  carrier_legs[0].T_erase_K:   2.725   → 2.725   (already correct)
  dead_state_T0_K:             2.72548 → 2.725

System: Neutron_Star_RXJ1856
  carrier_legs[0].T_sink_K:    2.725   → 2.725   (already correct)
  carrier_legs[0].T_erase_K:   2.725   → 2.725   (already correct)
  dead_state_T0_K:             2.72548 → 2.725

All black_holes[] entries:
  T_sink_K:                    2.725   → 2.725   (already correct)
  dead_state_T0_K:             2.72548 → 2.725   (where present)
```

### constants.py / tool.py fallback:
```
T_CMB = 2.725    (was 2.72548 in tool.py fallback — already correct there)
```

### mc_distributions.py:
```
T_FLOOR_CMB_K = 2.725   (done in this patch)
```

---

## 2. Rankine condenser uncertainty tightening

The condenser leg has T_source_K = 306.024 and T_sink_K = 298.15, a gap of
only ~8 K. At 1.0% uncertainty on each:
  - 1σ(T_source) = 3.06 K
  - 1σ(T_sink) = 2.98 K
  - Combined 1σ gap uncertainty ≈ 4.3 K (quadrature)
  - 8 K gap / 4.3 K σ ≈ 1.9σ → ~6% of draws have T_source ≤ T_sink

This is not a code bug — it's an uncertainty declaration bug. The CoolProp
EOS uncertainties on these MTT values are ~0.1-0.2%, not 1%. The 1%
reflected total process uncertainty including mass flow, but mass flow
uncertainty already enters through P_W (which has its own 2% declaration).
Double-counting mass flow uncertainty on both P_W and T inflates the CI.

### Patch:

```json
System: Supercritical_Steam_Rankine_500kgs

  carrier_legs[0] (boiler):
    uncertainty.T_source_K.uncertainty_pct:  1.0 → 0.2
    uncertainty.T_sink_K.uncertainty_pct:    1.0 → 0.2

  carrier_legs[1] (turbine):
    uncertainty.T_sink_K.uncertainty_pct:    1.0 → 0.2

  carrier_legs[2] (condenser):
    uncertainty.T_source_K.uncertainty_pct:  1.0 → 0.2
    uncertainty.T_sink_K.uncertainty_pct:    1.0 → 0.2

  carrier_legs[3] (pump):
    uncertainty.T_sink_K.uncertainty_pct:    (add) 0.2
```

At 0.2% uncertainty:
  - 1σ(T_source) = 0.61 K
  - 1σ(T_sink) = 0.60 K
  - Combined 1σ gap uncertainty ≈ 0.86 K
  - 8 K gap / 0.86 K σ ≈ 9.3σ → effectively zero impossible-exergy draws

P_W uncertainty stays at 2.0% — that's where the mass flow uncertainty
legitimately lives.

---

## 3. tool.py CANONICAL_ALPHA — radiation_spectral bug

### The bug:
```python
# In tool.py (current):
CANONICAL_ALPHA: Dict[str, float] = {
    "work":               0.0,
    "chemical":           0.0,
    "heat":               1.0,
    "radiation_bb":       4.0 / 3.0,
    "radiation_spectral": 4.0 / 3.0,   # ← WRONG
}
```

### Why it's wrong:

`radiation_spectral` is the ONLY carrier whose alpha genuinely varies. It
represents non-blackbody radiation where the entropy-to-energy ratio depends
on the spectral shape. The alpha_eff for a spectral carrier is a measured or
modeled quantity bounded by [0, 4/3], NOT a fixed constant.

By including `radiation_spectral` in `CANONICAL_ALPHA` with value 4/3,
`leg_alpha()` does:
```python
canonical = CANONICAL_ALPHA.get(cc, 0.0)  # returns 4/3 for radiation_spectral
return canonical                           # ignores the declared alpha_eff
```

This means every `radiation_spectral` leg silently gets alpha = 4/3 regardless
of the declared `alpha_eff`. A leg that should use alpha_eff = 0.8 (e.g.,
filtered solar radiation in a specific PAR band) gets 4/3 instead. The
Ndot calculation is wrong, the exergy is wrong, and there's no warning.

### The fix:

Remove `radiation_spectral` from `CANONICAL_ALPHA` in tool.py:
```python
CANONICAL_ALPHA: Dict[str, float] = {
    "work":         0.0,
    "chemical":     0.0,
    "heat":         1.0,
    "radiation_bb": 4.0 / 3.0,
    # radiation_spectral is NOT here — its alpha varies in [0, 4/3]
}
```

And update `leg_alpha()` to handle it:
```python
def leg_alpha(leg, strict=False):
    cc = carrier_canon(leg)
    if cc == "radiation_spectral":
        stored = leg.get("alpha_eff", leg.get("alpha"))
        if stored is None:
            raise ValueError(f"radiation_spectral leg requires alpha_eff")
        val = float(stored)
        if not (0.0 <= val <= 4.0/3.0 + 1e-9):
            raise ValueError(f"alpha_eff={val} outside Petela bounds [0, 4/3]")
        return val
    canonical = CANONICAL_ALPHA.get(cc, 0.0)
    # ... existing contradiction check ...
    return canonical
```

Our `carrier_constants.py` already implements this correctly.

---

## 4. Architecture notes (non-blocking)

### engine.py embedded in tool.py
The README documents `python3 tool.py data.json extract-engine` which writes
engine.py from a string literal inside tool.py. This is fragile — if tool.py
is edited, the embedded source silently diverges. Recommended: make engine.py
the primary file and have tool.py import from it.

### dynamic_analyzer.py and prompts.py
These exist in the zip but have no defined contract with the physics engine.
There's no validation interface, no schema for how an LLM-generated system
enters the ledger. They're dead weight until that contract is specified.
Not blocking — just documenting.
