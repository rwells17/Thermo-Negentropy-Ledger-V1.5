# Thermodynamic Negentropy Budget Toolkit

**Author:** Ryan Wells
**Version:** 1.5.0
**Python:** 3.11+

## What this does

You give it a thermodynamic system. It tells you three things:

1. How much entropy it produces (negentropy flux, J/K/s)
2. How much useful work it destroys (exergy destruction, watts)
3. How confident you should be in those numbers (Monte Carlo, 95% CI)

One formula drives everything: `Ndot = P * (1/T_sink - alpha/T_source)`

Alpha comes from the Second Law. It's not a tuning knob. Work carriers get alpha = 0. Heat gets alpha = 1. Blackbody radiation gets alpha = 4/3 (Petela 1964). The engine enforces this. If you try to override it, it tells you no.

The Monte Carlo sampler uses the right distributions for each parameter type. Power gets log-normal (multiplicative error). Temperatures get truncated normal with physics floors. Efficiencies get Beta (bounded 0 to 1). Canonical alphas are fixed at their exact values and never sampled. This matters because naive Gaussian sampling produces negative temperatures, efficiencies above 1, and biased confidence intervals. The engine doesn't do that.

## What it's been tested on

All of these ran through the same code path, same formula, verified against hand calculations to within 0.3%:

- 50 MW Anthropic data center (Austin TX, 35C ambient): 0.08% exergy efficiency, 10^28 Landauer bits/s
- Supercritical steam Rankine cycle (500 kg/s, CoolProp state points)
- The Sun (3.828e26 W, T_CMB dead state, Petela radiation exergy)
- Dyson sphere (full solar capture, 300K shell, 10^49 Landauer bits/s)
- Iceland Bitcoin mine with greenhouse waste heat recovery (25x more efficient than a data center)
- Underwater data centers (Natick-validated PUE within 1.6% of Microsoft's reported numbers)
- Lunar data center in a permanently shadowed crater (40K dead state, 198x Earth efficiency with TEG recovery)
- Data center scaling from 100 kW to 1 GW (linear Ndot scaling verified, zero deviation)

21 orders of magnitude. Same engine.

## Install

```
pip install numpy scipy
```

For visualization (optional):
```
pip install plotly
```

## Quick start

```python
from engine.uncertainty_propagation import monte_carlo_system, print_mc_report

# Define any system as carrier legs
system = {
    "dead_state_T0_K": 308.15,      # ambient temperature
    "P_input_W": 50_000_000.0,      # total input power
    "carrier_legs": [
        {
            "leg_id": "gpu_compute",
            "carrier": "work",       # work, heat, chemical, radiation_bb
            "P_W": 40_000_000.0,
            "alpha": 0.0,            # enforced by carrier type
            "T_source_K": None,      # null for work carriers
            "T_sink_K": 318.15,
            "eta_use": 0.001,
            "uncertainty": {
                "P_W": {"value": 40e6, "uncertainty_pct": 2.0},
                "T_sink_K": {"value": 318.15, "uncertainty_pct": 0.2},
                "eta_use": {"value": 0.001, "uncertainty_pct": 50.0}
            }
        },
        # ... more legs
    ],
}

result = monte_carlo_system(system, n_samples=50_000, seed=42)
print_mc_report(result)
```

That's it. You get Ndot, exergy, efficiency, Landauer bits, sensitivity analysis, and constraint diagnostics with 95% confidence intervals. Every number is reproducible with the same seed.

## Run the tests

```
pytest tests/ -v
```

69 tests. They cover the physics formulas, distribution bounds, RNG determinism, sensitivity analysis, constraint diagnostics, and regression baselines for the Sun and Rankine cycle.

## File structure

```
engine/
    carrier_constants.py     Alpha values as Second Law structural constants
    mc_distributions.py      Regime-aware distributions (Beta, LogNormal, TruncNorm)
    uncertainty_propagation.py   Monte Carlo engine, system aggregation, reporting

tests/
    test_thermodynamic_engine.py   69 tests, ~3 seconds

examples/
    anthropic_dc_50mw_system.json      50 MW data center definition
    anthropic_dc_50mw_result.json      Full MC result with 50k samples
    dyson_sphere_system.json           Dyson sphere (full solar capture)
    dyson_sphere_result.json           MC result
    lunar_dc_C_cold_optimized_system.json   Moon crater data center
    lunar_dc_C_cold_optimized_result.json   MC result
    underwater_dc_comparison.json      7-scenario underwater vs Earth comparison
```

## The physics

Every number traces back to one formula. Take the GPU leg from the data center:

```
Ndot = P / T_sink = 40,000,000 / 318.15 = 125,726.86 J/K/s
```

The MC engine returned 125,725.19. That's a 0.001% discrepancy from sampling noise on 50,000 draws. You can check it on a calculator.

For heat carriers:
```
Ndot = P * (1/T_sink - 1/T_source)
```

For blackbody radiation (Petela):
```
W_ex = P * (1 - (4/3)*r + (1/3)*r^4)    where r = T_sink/T_source
```

Landauer conversion:
```
bits/s = Ndot / (k_B * ln(2))
```

That's the whole engine. The rest is correct sampling, honest error bars, and not lying about what you don't know.

## What this doesn't do

It doesn't simulate fluid dynamics. It doesn't resolve state points from equations of state (use CoolProp for that, feed the results in as carrier legs). It doesn't model transient behavior beyond what you can express as a time series of steady states. It doesn't optimize anything. It audits.

## Known issues

`tool.py` (the CLI validator, not included here) still has a bug where `radiation_spectral` is hardcoded to alpha = 4/3 in its local `CANONICAL_ALPHA` dict. This silently corrupts any spectral radiation leg. The fix is documented in `TOOL_PY_PATCH.py`. The engine modules in this repo handle it correctly.

## Built with AI

Yes. The remediation, testing, and analysis in this repo were done in collaboration with Claude (Anthropic). The physics is verified. Every number matches hand calculations. If that bothers you, check the math. It doesn't care who typed it.

## License

BSD-3-Clause

## References

- Petela, R. (1964). Exergy of heat radiation. J. Heat Transfer 86(2), 187-192.
- Clausius, R. (1865). Mechanical Theory of Heat.
- Fixsen, D.J. (2009). The Temperature of the Cosmic Microwave Background. ApJ 707(2): 916-920.
- Landauer, R. (1961). Irreversibility and Heat Generation in the Computing Process. IBM J. Res. Dev. 5(3): 183-191.
- CODATA 2018. k_B = 1.380649e-23 J/K (exact, SI 2019 redefinition).
