"""test_thermodynamic_engine.py

Automated regression test suite for the Negentropy Ledger physics engine.

Run:  pytest test_thermodynamic_engine.py -v
      pytest test_thermodynamic_engine.py -v --tb=short -q   (CI mode)

Covers:
    1. carrier_constants.py  — canonical alpha values, name resolution, enforcement
    2. mc_distributions.py   — distribution shapes, bounds, edge cases, constraint audit
    3. uncertainty_propagation.py — single-pass RNG, CI consistency, determinism, sensitivity
"""
import math
import sys
import os

import numpy as np
import pytest

# ---------------------------------------------------------------------------
# Ensure package is importable
# ---------------------------------------------------------------------------
sys.path.insert(0, os.path.dirname(__file__))

from engine.carrier_constants import (
    CANONICAL_ALPHA, RADIATION_SPECTRAL_ALPHA_BOUNDS,
    canonical_name, canonical_alpha, enforce_canonical_alpha,
    validate_all_legs, alpha_for_mc, _ALPHA_TOL,
)
from engine.mc_distributions import (
    T_FLOOR_CMB_K, T_FLOOR_ENGINEERING_K, T_FLOOR_ABSOLUTE_K,
    INVALID_DRAW_WARN_THRESHOLD, INVALID_DRAW_ERROR_THRESHOLD,
    sample_temperature, sample_power, sample_efficiency,
    check_physical_constraints, interpret_constraint_violations,
    t_floor_for_regime, select_distribution,
    _lognormal_params, _beta_params,
)
from engine.uncertainty_propagation import (
    monte_carlo_leg, monte_carlo_system, _leg_ndot_vec, _leg_wex_vec,
    _ALPHA_EPS, BITS_PER_J_PER_K, __version__ as up_version,
)


# ===========================================================================
# FIXTURES
# ===========================================================================
@pytest.fixture
def rng():
    return np.random.default_rng(42)


@pytest.fixture
def n():
    return 20_000


@pytest.fixture
def rankine_system():
    """Supercritical Steam Rankine 500 kg/s — from data.json with tightened uncertainties."""
    return {
        "dead_state_T0_K": 298.15,
        "regime": "engineering",
        "P_input_W": 1677875940.7049189,
        "carrier_legs": [
            {
                "leg_id": "boiler",
                "carrier": "heat",
                "alpha": 1.0,
                "P_W": 1662254588.2123866,
                "T_source_K": 566.632,
                "T_sink_K": 298.15,
                "eta_use": 1.0,
                "uncertainty": {
                    "P_W": {"value": 1662254588.2123866, "uncertainty_pct": 2.0,
                            "source_quality": "coolprop_eos"},
                    "T_source_K": {"value": 566.632, "uncertainty_pct": 0.2,
                                   "source_quality": "coolprop_eos"},
                    "T_sink_K": {"value": 298.15, "uncertainty_pct": 0.2,
                                 "source_quality": "coolprop_eos"},
                },
            },
            {
                "leg_id": "turbine",
                "carrier": "work",
                "alpha": 0.0,
                "P_W": 660468932.1634858,
                "T_source_K": None,
                "T_sink_K": 306.024,
                "eta_use": 1.0,
                "uncertainty": {
                    "P_W": {"value": 660468932.1634858, "uncertainty_pct": 2.0,
                            "source_quality": "coolprop_eos"},
                    "T_sink_K": {"value": 306.024, "uncertainty_pct": 0.2,
                                 "source_quality": "coolprop_eos"},
                },
            },
            {
                "leg_id": "condenser",
                "carrier": "heat",
                "alpha": 1.0,
                "P_W": 1017407008.5414331,
                "T_source_K": 306.024,
                "T_sink_K": 298.15,
                "eta_use": 1.0,
                "uncertainty": {
                    "P_W": {"value": 1017407008.5414331, "uncertainty_pct": 2.0,
                            "source_quality": "coolprop_eos"},
                    "T_source_K": {"value": 306.024, "uncertainty_pct": 0.2,
                                   "source_quality": "coolprop_eos"},
                    "T_sink_K": {"value": 298.15, "uncertainty_pct": 0.2,
                                 "source_quality": "coolprop_eos"},
                },
            },
            {
                "leg_id": "pump",
                "carrier": "work",
                "alpha": 0.0,
                "P_W": 15621352.492532155,
                "T_source_K": None,
                "T_sink_K": 308.166,
                "eta_use": 1.0,
                "uncertainty": {
                    "P_W": {"value": 15621352.492532155, "uncertainty_pct": 2.0,
                            "source_quality": "coolprop_eos"},
                    "T_sink_K": {"value": 308.166, "uncertainty_pct": 0.2,
                                 "source_quality": "coolprop_eos"},
                },
            },
        ],
    }


@pytest.fixture
def sun_system():
    """Sun system with CMB dead state."""
    return {
        "dead_state_T0_K": 2.725,
        "regime": "astrophysics_stellar_surface",
        "carrier_legs": [
            {
                "leg_id": "L1",
                "carrier": "radiation_bb",
                "P_W": 3.828e+26,
                "alpha": 4.0 / 3.0,
                "T_source_K": 5772.0,
                "T_sink_K": 2.725,
                "eta_use": 1.0,
                "uncertainty": {
                    "P_W": {"value": 3.828e+26, "uncertainty_pct": 1.0},
                    "T_source_K": {"value": 5772.0, "uncertainty_pct": 0.5},
                    "T_sink_K": {"value": 2.725, "uncertainty_pct": 0.5},
                },
            },
        ],
    }


# ===========================================================================
# CARRIER CONSTANTS
# ===========================================================================
class TestCarrierConstants:
    """Tests for carrier_constants.py"""

    def test_canonical_alpha_values(self):
        assert CANONICAL_ALPHA["work"] == 0.0
        assert CANONICAL_ALPHA["chemical"] == 0.0
        assert CANONICAL_ALPHA["heat"] == 1.0
        assert abs(CANONICAL_ALPHA["radiation_bb"] - 4.0 / 3.0) < 1e-15

    def test_radiation_spectral_not_in_canonical(self):
        """radiation_spectral must NOT be in CANONICAL_ALPHA.
        It varies in [0, 4/3]; hardcoding it to 4/3 is a physics error that
        destroys the declared alpha_eff for every spectral radiation leg.
        This is the bug in tool.py's CANONICAL_ALPHA dict."""
        assert "radiation_spectral" not in CANONICAL_ALPHA

    def test_petela_bounds(self):
        lo, hi = RADIATION_SPECTRAL_ALPHA_BOUNDS
        assert lo == 0.0
        assert abs(hi - 4.0 / 3.0) < 1e-15

    @pytest.mark.parametrize("alias,expected", [
        ("electricity", "work"), ("mechanical", "work"), ("electric", "work"),
        ("shaft", "work"), ("shaft_work", "work"),
        ("heat", "heat"), ("work", "work"), ("chemical", "chemical"),
        ("radiation_bb", "radiation_bb"), ("radiation_spectral", "radiation_spectral"),
    ])
    def test_canonical_name_resolution(self, alias, expected):
        assert canonical_name(alias) == expected

    def test_unknown_carrier_raises(self):
        with pytest.raises(ValueError, match="Unknown carrier"):
            canonical_name("unobtanium")

    def test_enforce_canonical_alpha_pass(self):
        ok, msg = enforce_canonical_alpha("heat", 1.0, strict=False)
        assert ok and msg == ""

    def test_enforce_canonical_alpha_fail(self):
        ok, msg = enforce_canonical_alpha("heat", 0.8, strict=False)
        assert not ok
        assert "Clausius" in msg

    def test_enforce_canonical_alpha_strict_raises(self):
        with pytest.raises(ValueError):
            enforce_canonical_alpha("heat", 0.8, strict=True)

    def test_enforce_spectral_in_bounds(self):
        ok, _ = enforce_canonical_alpha("radiation_spectral", 1.2, strict=False)
        assert ok

    def test_enforce_spectral_out_of_bounds(self):
        ok, msg = enforce_canonical_alpha("radiation_spectral", 1.5, strict=False)
        assert not ok
        assert "Petela" in msg

    def test_alpha_for_mc_canonical_override(self):
        """alpha_for_mc must return canonical value regardless of declared."""
        assert alpha_for_mc("heat", 0.8) == 1.0
        assert alpha_for_mc("work", 999.0) == 0.0
        assert alpha_for_mc("radiation_bb", 0.5) == 4.0 / 3.0

    def test_alpha_for_mc_spectral_passthrough(self):
        assert alpha_for_mc("radiation_spectral", 0.7) == 0.7

    def test_validate_all_legs(self):
        legs = [
            {"carrier": "heat", "alpha": 1.0, "leg_id": "h1"},
            {"carrier": "work", "alpha": 0.0, "leg_id": "w1"},
        ]
        ok, errors = validate_all_legs(legs, strict=False)
        assert ok and len(errors) == 0

    def test_validate_all_legs_bad_alpha(self):
        legs = [{"carrier": "heat", "alpha": 0.5, "leg_id": "bad"}]
        ok, errors = validate_all_legs(legs, strict=False)
        assert not ok and len(errors) == 1


# ===========================================================================
# MC DISTRIBUTIONS
# ===========================================================================
class TestMCDistributions:
    """Tests for mc_distributions.py"""

    def test_cmb_temperature_3dp(self):
        """T_FLOOR_CMB_K must be 2.725 (3 dp for readability)."""
        assert T_FLOOR_CMB_K == 2.725

    def test_temperature_always_above_floor(self, rng, n):
        T = sample_temperature(300.0, 10.0, n, rng, t_floor_K=2.725)
        assert T.min() > 2.725

    def test_temperature_mean_near_nominal(self, rng, n):
        T = sample_temperature(500.0, 5.0, n, rng)
        assert abs(T.mean() / 500.0 - 1.0) < 0.02

    def test_temperature_zero_uncertainty(self, rng, n):
        T = sample_temperature(400.0, 0.0, n, rng)
        assert np.all(T == 400.0)

    def test_power_always_positive(self, rng, n):
        P = sample_power(1e9, 5.0, n, rng)
        assert P.min() > 0

    def test_power_mean_near_nominal(self, rng, n):
        P = sample_power(1e6, 2.0, n, rng)
        assert abs(P.mean() / 1e6 - 1.0) < 0.02

    def test_power_zero_uncertainty(self, rng, n):
        P = sample_power(1e6, 0.0, n, rng)
        assert np.all(P == 1e6)

    def test_efficiency_bounded_01(self, rng, n):
        eta = sample_efficiency(0.85, 15.0, n, rng)
        assert eta.min() >= 0.0
        assert eta.max() <= 1.0

    def test_efficiency_mean_near_nominal(self, rng, n):
        eta = sample_efficiency(0.38, 10.0, n, rng)
        assert abs(eta.mean() - 0.38) < 0.02

    def test_efficiency_zero_uncertainty(self, rng, n):
        eta = sample_efficiency(0.5, 0.0, n, rng)
        assert np.all(eta == 0.5)

    def test_efficiency_near_boundary(self, rng, n):
        eta = sample_efficiency(0.99, 5.0, n, rng)
        assert eta.max() <= 1.0

    def test_constraint_audit_clean(self, rng, n):
        P = sample_power(1e6, 2.0, n, rng)
        T_src = sample_temperature(600.0, 2.0, n, rng)
        T_snk = sample_temperature(300.0, 2.0, n, rng)
        v = check_physical_constraints(P, T_src, T_snk)
        assert v["impossible_exergy_frac"] < 0.001

    def test_constraint_audit_tight_temps(self, rng, n):
        P = sample_power(1e6, 2.0, n, rng)
        T_src = sample_temperature(305.0, 5.0, n, rng)
        T_snk = sample_temperature(295.0, 5.0, n, rng)
        v = check_physical_constraints(P, T_src, T_snk)
        assert v["impossible_exergy_frac"] > 0.01
        sev, _ = interpret_constraint_violations(v)
        assert sev in ("warn", "error")

    def test_lognormal_roundtrip(self, rng):
        mu, sig = _lognormal_params(1000.0, 0.05)
        samples = rng.lognormal(mean=mu, sigma=sig, size=100_000)
        assert abs(samples.mean() / 1000.0 - 1.0) < 0.01

    def test_beta_degenerate(self):
        a, b = _beta_params(0.5, 0.0001)
        assert a > 1e5 or b > 1e5

    @pytest.mark.parametrize("param,expected", [
        ("P_W", "lognormal"), ("T_source_K", "truncnorm"),
        ("T_sink_K", "truncnorm"), ("eta_use", "beta"),
    ])
    def test_distribution_selection(self, param, expected):
        assert select_distribution(param) == expected

    def test_regime_floor_astrophysics(self):
        assert t_floor_for_regime("astrophysics_stellar_surface") == T_FLOOR_CMB_K

    def test_regime_floor_engineering(self):
        assert t_floor_for_regime("engineering") == T_FLOOR_ENGINEERING_K


# ===========================================================================
# UNCERTAINTY PROPAGATION
# ===========================================================================
class TestUncertaintyPropagation:
    """Tests for uncertainty_propagation.py"""

    def test_ndot_vec_alpha_tolerance(self):
        """alpha comparison must use tolerance, not exact float ==."""
        P = np.ones(100) * 1e6
        T_snk = np.ones(100) * 300.0
        T_src = np.ones(100) * 600.0
        ndot_0 = _leg_ndot_vec(P, T_snk, T_src, 0.0)
        ndot_eps = _leg_ndot_vec(P, T_snk, T_src, 1e-15)
        assert np.allclose(ndot_0, ndot_eps)

    def test_ndot_heat_formula(self):
        P = np.array([1e6])
        T_snk = np.array([300.0])
        T_src = np.array([600.0])
        result = _leg_ndot_vec(P, T_snk, T_src, 1.0)
        expected = 1e6 * (1.0 / 300.0 - 1.0 / 600.0)
        assert abs(result[0] - expected) < 1e-10

    def test_wex_petela_formula(self):
        P = np.array([1e6])
        T_snk = np.array([300.0])
        T_src = np.array([600.0])
        result = _leg_wex_vec(P, T_snk, T_src, "radiation_bb")
        r = 300.0 / 600.0
        expected = 1e6 * (1.0 - (4.0 / 3.0) * r + (1.0 / 3.0) * r ** 4)
        assert abs(result[0] - expected) < 1e-6

    def test_wex_work_is_identity(self):
        P = np.array([1e6])
        T_snk = np.array([300.0])
        result = _leg_wex_vec(P, T_snk, None, "work")
        assert result[0] == 1e6

    def test_per_leg_returns_raw_arrays(self):
        leg = {
            "leg_id": "t", "carrier": "heat", "alpha": 1.0,
            "P_W": 1e6, "T_source_K": 600.0, "T_sink_K": 300.0,
        }
        result = monte_carlo_leg(leg, n_samples=100, rng=np.random.default_rng(1))
        assert "_Ndot_raw" in result
        assert "_P_s" in result
        assert len(result["_Ndot_raw"]) == 100

    def test_per_leg_alpha_canonical_override(self):
        leg = {
            "leg_id": "t", "carrier": "heat", "alpha": 0.8,
            "P_W": 1e6, "T_source_K": 600.0, "T_sink_K": 300.0,
        }
        result = monte_carlo_leg(leg, n_samples=100, rng=np.random.default_rng(1))
        assert result["alpha_used"] == 1.0
        assert result["alpha_is_canonical_fixed"] is True

    def test_system_determinism(self, rankine_system):
        r1 = monte_carlo_system(rankine_system, n_samples=5000, seed=42)
        r2 = monte_carlo_system(rankine_system, n_samples=5000, seed=42)
        assert r1["system_totals"]["Ndot_J_per_K_s"]["mean"] == \
               r2["system_totals"]["Ndot_J_per_K_s"]["mean"]

    def test_system_raw_arrays_stripped(self, rankine_system):
        result = monte_carlo_system(rankine_system, n_samples=1000, seed=42)
        for lr in result["per_leg"]:
            assert "_Ndot_raw" not in lr
            assert "_P_s" not in lr

    def test_system_confidence_level_consistent(self, rankine_system):
        result = monte_carlo_system(rankine_system, n_samples=1000, seed=42,
                                    confidence_level=0.99)
        for lr in result["per_leg"]:
            assert lr["confidence_level"] == 0.99

    def test_system_sensitivity_valid(self, rankine_system):
        result = monte_carlo_system(rankine_system, n_samples=5000, seed=42)
        for k, v in result["sensitivity"].items():
            assert -1.0 <= v <= 1.0
            # Spearman rho: all legs should have some positive monotonic
            # relationship with total (they contribute additively)
            assert v > -0.5, f"Sensitivity suspiciously negative: {k}={v}"

    def test_eta_use_sampled_when_declared(self):
        """When eta_use has declared uncertainty, it should be sampled (Beta)
        and should widen the W_ex CI compared to no eta uncertainty."""
        leg_no_eta_unc = {
            "leg_id": "t", "carrier": "heat", "alpha": 1.0,
            "P_W": 1e6, "T_source_K": 600.0, "T_sink_K": 300.0,
            "eta_use": 0.5,
        }
        leg_with_eta_unc = {
            "leg_id": "t", "carrier": "heat", "alpha": 1.0,
            "P_W": 1e6, "T_source_K": 600.0, "T_sink_K": 300.0,
            "eta_use": 0.5,
            "uncertainty": {
                "P_W": {"value": 1e6, "uncertainty_pct": 2.0},
                "T_source_K": {"value": 600.0, "uncertainty_pct": 0.5},
                "T_sink_K": {"value": 300.0, "uncertainty_pct": 0.5},
                "eta_use": {"value": 0.5, "uncertainty_pct": 10.0},
            },
        }
        r1 = monte_carlo_leg(leg_no_eta_unc, n_samples=5000,
                             rng=np.random.default_rng(42))
        r2 = monte_carlo_leg(leg_with_eta_unc, n_samples=5000,
                             rng=np.random.default_rng(42))
        # With eta uncertainty, W_ex CI should be wider
        ci_width_1 = r1["W_ex_clamped_W"]["ci_upper"] - r1["W_ex_clamped_W"]["ci_lower"]
        ci_width_2 = r2["W_ex_clamped_W"]["ci_upper"] - r2["W_ex_clamped_W"]["ci_lower"]
        assert ci_width_2 > ci_width_1, (
            f"eta_use uncertainty should widen W_ex CI: "
            f"without={ci_width_1:.0f}, with={ci_width_2:.0f}"
        )
        # eta_use should appear in distribution_types
        assert "eta_use" in r2["distribution_types"]
        assert r2["distribution_types"]["eta_use"] == "beta"

    def test_eta_use_1_not_sampled(self):
        """eta_use=1.0 with no declared uncertainty should NOT be sampled
        (no 5% fallback imputed on a definitional ideal)."""
        leg = {
            "leg_id": "t", "carrier": "work", "alpha": 0.0,
            "P_W": 1e6, "T_sink_K": 300.0, "eta_use": 1.0,
        }
        result = monte_carlo_leg(leg, n_samples=100, rng=np.random.default_rng(1))
        assert "eta_use" not in result["distribution_types"]

    def test_system_no_t0_warning(self, rankine_system):
        """When T0 is declared, no warning should fire."""
        result = monte_carlo_system(rankine_system, n_samples=1000, seed=42)
        t0_warns = [w for w in result.get("warnings", []) if "dead_state_T0_K" in w]
        assert len(t0_warns) == 0

    def test_system_missing_t0_warning(self, rankine_system):
        sys_no_t0 = dict(rankine_system)
        del sys_no_t0["dead_state_T0_K"]
        sys_no_t0["carrier_legs"] = list(rankine_system["carrier_legs"])
        result = monte_carlo_system(sys_no_t0, n_samples=500, seed=42)
        t0_warns = [w for w in result.get("warnings", []) if "dead_state_T0_K" in w]
        assert len(t0_warns) > 0

    def test_rankine_condenser_tightened_no_error(self, rankine_system):
        """With 0.2% uncertainty, the condenser (306K vs 298K, 8K gap) should
        NOT produce >10% invalid draws. The old 1.0% uncertainty did."""
        result = monte_carlo_system(rankine_system, n_samples=10_000, seed=42)
        for lr in result["per_leg"]:
            if lr["leg_id"] == "condenser":
                inv = lr["physical_constraint_audit"]["impossible_exergy_frac"]
                assert inv < 0.10, (
                    f"Condenser still has {inv*100:.1f}% impossible exergy draws. "
                    f"Uncertainty too wide for the 8K T_source-T_sink gap."
                )

    def test_sun_system_cmb_floor(self, sun_system):
        result = monte_carlo_system(sun_system, n_samples=5000, seed=42)
        assert result["status"] == "ok"
        st = result["system_totals"]
        assert st["Ndot_J_per_K_s"]["mean"] > 0
        assert st["eta_system"]["mean"] > 0.99  # Sun is nearly Carnot-limited

    def test_bits_per_j_per_k_constant(self):
        """Verify Landauer conversion factor."""
        K_B = 1.380649e-23
        expected = 1.0 / (K_B * math.log(2))
        assert abs(BITS_PER_J_PER_K / expected - 1.0) < 1e-10


# ===========================================================================
# REGRESSION BASELINES (pin against known-good results)
# ===========================================================================
class TestRegressionBaselines:
    """Pin specific numerical results to detect silent changes."""

    def test_version_strings_consistent(self):
        """All three modules must declare __version__ and agree."""
        from engine.carrier_constants import __version__ as v1
        from engine.mc_distributions import __version__ as v2
        from engine.uncertainty_propagation import __version__ as v3
        assert v1 == v2 == v3
        assert v1 == "1.5.0"

    def test_sun_ndot_order_of_magnitude(self, sun_system):
        result = monte_carlo_system(sun_system, n_samples=10_000, seed=42)
        ndot = result["system_totals"]["Ndot_J_per_K_s"]["mean"]
        # Sun Ndot ~ 1.4e26 J/K/s
        assert 1e25 < ndot < 1e27, f"Sun Ndot = {ndot:.3e}, expected ~1.4e26"

    def test_rankine_ndot_order_of_magnitude(self, rankine_system):
        result = monte_carlo_system(rankine_system, n_samples=10_000, seed=42)
        ndot = result["system_totals"]["Ndot_J_per_K_s"]["mean"]
        # Rankine system Ndot ~ 4.9e6 J/K/s
        assert 1e6 < ndot < 1e8, f"Rankine Ndot = {ndot:.3e}, expected ~4.9e6"

    def test_petela_factor_numerical(self):
        """Petela factor for Sun: 1 - (4/3)*r + (1/3)*r^4 where r = T_CMB/T_sun."""
        r = 2.725 / 5772.0
        factor = 1.0 - (4.0 / 3.0) * r + (1.0 / 3.0) * r ** 4
        assert abs(factor - 0.99937) < 0.001  # Sun is ~99.94% Petela efficient

    def test_runtime_provenance_present(self, rankine_system):
        result = monte_carlo_system(rankine_system, n_samples=500, seed=42)
        prov = result["runtime_provenance"]
        assert prov["engine_version"] == "1.5.0"
        assert prov["mc_distributions_available"] is True
        assert prov["carrier_constants_available"] is True
        assert "regime-aware" in prov["distribution_backend"]

    def test_t_gap_diagnostic_in_constraint_audit(self):
        """When T_source and T_sink are close with wide uncertainty,
        the constraint audit should return T-gap diagnostic fields."""
        rng = np.random.default_rng(42)
        n = 10_000
        P = sample_power(1e6, 2.0, n, rng)
        T_src = sample_temperature(308.0, 3.0, n, rng)  # wide uncertainty
        T_snk = sample_temperature(300.0, 3.0, n, rng)  # wide uncertainty, 8K gap
        v = check_physical_constraints(P, T_src, T_snk)
        # T-gap diagnostic fields must be present
        assert "T_gap_mean_K" in v
        assert "T_gap_std_K" in v
        assert "T_gap_sigma_ratio" in v
        assert v["T_gap_mean_K"] > 0  # nominal gap is positive
        assert v["T_gap_sigma_ratio"] < 10  # gap is not huge relative to sigma

    def test_t_gap_diagnostic_triggers_specific_message(self):
        """interpret_constraint_violations should mention 'T-uncertainty-too-wide'
        when gap/sigma is small and impossible_exergy is high."""
        violations = {
            "negative_power_frac": 0.0,
            "impossible_exergy_frac": 0.25,
            "below_dead_state_frac": 0.0,
            "any_invalid_frac": 0.25,
            "T_gap_mean_K": 8.0,
            "T_gap_std_K": 4.0,
            "T_gap_sigma_ratio": 2.0,
        }
        sev, msg = interpret_constraint_violations(violations)
        assert sev == "error"
        assert "T-uncertainty-too-wide" in msg

    def test_t_gap_diagnostic_fundamentally_inconsistent(self):
        """When nominal gap is negative, should say 'fundamentally inconsistent'."""
        violations = {
            "negative_power_frac": 0.0,
            "impossible_exergy_frac": 0.80,
            "below_dead_state_frac": 0.0,
            "any_invalid_frac": 0.80,
            "T_gap_mean_K": -5.0,
            "T_gap_std_K": 3.0,
            "T_gap_sigma_ratio": -1.67,
        }
        sev, msg = interpret_constraint_violations(violations)
        assert sev == "error"
        assert "fundamentally inconsistent" in msg
